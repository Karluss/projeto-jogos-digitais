level_map = [
'                                  ',
'                                  ',
'      P                           ',
'                                  ',
'                                  ',
'                                  ',
'   X                      X       ',
'XXXXXXX   XXXXXXXXXXXX   XXXXXXXXX',
]

tile_size = 64
screen_width = 1200
screen_height = tile_size * len(level_map)